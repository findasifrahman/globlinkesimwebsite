from fastapi import FastAPI, Request
import logging

app = FastAPI()

# Configure logging to write to stdout
logging.basicConfig(level=logging.INFO)

@app.post("/globlinkesimwebhook")
async def webhook_listener(request: Request):
    payload = await request.json()
    logging.info(f"Webhook received: {payload}")
    return {"status": "ok"}
